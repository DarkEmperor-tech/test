﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5.Models
{
    public class Cell
    {
        public CellState State { get; set; }
        public int X { get; }
        public int Y { get; }

        public Cell(int x, int y, CellState state = CellState.Empty)
        {
            X = x;
            Y = y;
            State = state;
        }
    }
}
