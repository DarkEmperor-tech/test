﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using Newtonsoft.Json;

namespace Lab5.Models
{
    public class SchellingModel
    {
        public Cell[,] Grid { get; private set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public double SimilarityThreshold { get; set; } = 0.3;
        public int EmptyCells { get; private set; }

        public SchellingModel(int width, int height)
        {
            Width = width;
            Height = height;
            Grid = new Cell[width, height];
            InitializeGrid();
        }
        public (int happyCount, int unhappyCount) GetAgentHappinessStats()
        {
            int happyCount = 0;
            int unhappyCount = 0;

            for (int x = 0; x < Width; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    var cell = Grid[x, y];
                    if (cell.State != CellState.Empty)
                    {
                        if (IsHappy(x, y))
                        {
                            happyCount++;
                        }
                        else
                        {
                            unhappyCount++;
                        }
                    }
                }
            }

            return (happyCount, unhappyCount);
        }

        private void InitializeGrid()
        {
            for (int x = 0; x < Width; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    Grid[x, y] = new Cell(x, y);
                }
            }
        }

        public void Randomize(double density, double redRatio)
        {
            var random = new Random();
            EmptyCells = (int)(Width * Height * (1 - density));

            for (int x = 0; x < Width; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    if (random.NextDouble() > density)
                    {
                        Grid[x, y].State = CellState.Empty;
                    }
                    else
                    {
                        Grid[x, y].State = random.NextDouble() < redRatio ? CellState.Red : CellState.Blue;
                    }
                }
            }
        }

        public void Step()
        {
            var random = new Random();
            var unhappyAgents = new List<Cell>();

            for (int x = 0; x < Width; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    if (Grid[x, y].State != CellState.Empty && !IsHappy(x, y))
                    {
                        unhappyAgents.Add(Grid[x, y]);
                    }
                }
            }

            foreach (var cell in unhappyAgents.OrderBy(_ => random.Next()))
            {
                var emptyCells = GetEmptyCells().OrderBy(_ => random.Next()).ToList();
                if (emptyCells.Any())
                {
                    var target = emptyCells.First();
                    target.State = cell.State;
                    cell.State = CellState.Empty;
                }
            }
        }
        
        private bool IsHappy(int x, int y)
        {
            if (Grid[x, y].State == CellState.Empty) return true;

            var neighbors = GetNeighbors(x, y);
            if (neighbors.Count == 0) return true;

            int similar = neighbors.Count(n => n.State == Grid[x, y].State);
            double ratio = (double)similar / neighbors.Count;

            return ratio >= SimilarityThreshold;
        }
        
        private List<Cell> GetNeighbors(int x, int y)
        {
            var neighbors = new List<Cell>();

            for (int dx = -1; dx <= 1; dx++)
            {
                for (int dy = -1; dy <= 1; dy++)
                {
                    if (dx == 0 && dy == 0) continue;

                    int nx = x + dx;
                    int ny = y + dy;

                    if (nx >= 0 && nx < Width && ny >= 0 && ny < Height && Grid[nx, ny].State != CellState.Empty)
                    {
                        neighbors.Add(Grid[nx, ny]);
                    }
                }
            }

            return neighbors;
        }

        private IEnumerable<Cell> GetEmptyCells()
        {
            for (int x = 0; x < Width; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    if (Grid[x, y].State == CellState.Empty)
                    {
                        yield return Grid[x, y];
                    }
                }
            }
        }

        public void SaveToFile(string path)
        {
            var data = new
            {
                Width,
                Height,
                SimilarityThreshold,
                Cells = Grid.Cast<Cell>().Select(c => new { c.X, c.Y, c.State }).ToList()
            };

            File.WriteAllText(path, JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.Indented));
        }

        public void LoadFromFile(string path)
        {
            var data = JsonConvert.DeserializeAnonymousType(
                File.ReadAllText(path),
                new { Width = 0, Height = 0, SimilarityThreshold = 0.3, Cells = new List<dynamic>() });

            this.Width = data.Width;
            this.Height = data.Height;
            this.SimilarityThreshold = data.SimilarityThreshold;

            Grid = new Cell[data.Width, data.Height];
            for (int x = 0; x < data.Width; x++)
            {
                for (int y = 0; y < data.Height; y++)
                {
                    Grid[x, y] = new Cell(x, y);
                }
            }

            foreach (var cell in data.Cells)
            {
                Grid[cell.X, cell.Y].State = (CellState)Enum.Parse(typeof(CellState), cell.State.ToString());
            }
        }
    }
}