﻿using Lab5.Models;
using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace Lab5.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private SchellingModel _model;
        private DispatcherTimer _timer;
        private int _speed = 1;

        public int Width { get; set; } = 50;
        public int Height { get; set; } = 50;
        public double Density { get; set; } = 0.8;
        public double RedRatio { get; set; } = 0.7;
        public double SimilarityThreshold { get; set; } = 0.5;
        private int _happyAgents;
        private int _unhappyAgents;

        public int HappyAgents
        {
            get => _happyAgents;
            set
            {
                _happyAgents = value;
                OnPropertyChanged();
            }
        }

        public int UnhappyAgents
        {
            get => _unhappyAgents;
            set
            {
                _unhappyAgents = value;
                OnPropertyChanged();
            }
        }

        public int Speed
        {
            get => _speed;
            set
            {
                _speed = value;
                if (_timer != null)
                {
                    _timer.Interval = TimeSpan.FromMilliseconds(1000 / value);
                }
                OnPropertyChanged();
            }
        }

        public bool IsRunning => _timer?.IsEnabled ?? false;

        public Cell[,] Grid => _model?.Grid;

        public IEnumerable<Cell> Cells
        {
            get
            {
                if (Grid == null) yield break;

                for (int x = 0; x < Grid.GetLength(0); x++)
                {
                    for (int y = 0; y < Grid.GetLength(1); y++)
                    {
                        yield return Grid[x, y];
                    }
                }
            }
        }

        public ICommand InitializeCommand { get; }
        public ICommand RandomizeCommand { get; }
        public ICommand StartCommand { get; }
        public ICommand StopCommand { get; }
        public ICommand StepCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand LoadCommand { get; }
        public ICommand LeftCellClickCommand { get; }
        public ICommand RightCellClickCommand { get; }

        public MainViewModel()
        {
            InitializeCommand = new RelayCommand(_ => InitializeModel());
            RandomizeCommand = new RelayCommand(_ => RandomizeModel());
            StartCommand = new RelayCommand(_ => StartSimulation());
            StopCommand = new RelayCommand(_ => StopSimulation());
            StepCommand = new RelayCommand(_ => StepSimulation());
            SaveCommand = new RelayCommand(_ => SaveModel());
            LoadCommand = new RelayCommand(_ => LoadModel());
            LeftCellClickCommand = new RelayCommand(OnLeftCellClicked);
            RightCellClickCommand = new RelayCommand(OnRightCellClicked);
        }

        private void InitializeModel()
        {
            _model = new SchellingModel(Width, Height)
            {
                SimilarityThreshold = SimilarityThreshold
            };
            OnPropertyChanged(nameof(Grid));
            OnPropertyChanged(nameof(Cells));
        }

        private void RandomizeModel()
        {
            if (_model == null) InitializeModel();
            _model.Randomize(Density, RedRatio);
            OnPropertyChanged(nameof(Grid));
            OnPropertyChanged(nameof(Cells));
        }

        private void StartSimulation()
        {
            if (_model == null) InitializeModel();

            if (_timer == null)
            {
                _timer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromMilliseconds(1000 / Speed)
                };
                _timer.Tick += (s, e) => StepSimulation();
            }

            _timer.Start();
            OnPropertyChanged(nameof(IsRunning));
        }

        private void StopSimulation()
        {
            _timer?.Stop();
            OnPropertyChanged(nameof(IsRunning));
        }

        private void StepSimulation()
        {
            _model.Step();
            var (happy, unhappy) = _model.GetAgentHappinessStats();
            HappyAgents = happy;
            UnhappyAgents = unhappy;
            OnPropertyChanged(nameof(Grid));
            OnPropertyChanged(nameof(Cells));
        }

        private void SaveModel()
        {
            var saveDialog = new SaveFileDialog
            {
                Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                DefaultExt = ".json"
            };

            if (saveDialog.ShowDialog() == true)
            {
                try
                {
                    _model.SaveToFile(saveDialog.FileName);
                    MessageBox.Show("Model saved successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error saving model: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void LoadModel()
        {
            var openDialog = new OpenFileDialog
            {
                Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                DefaultExt = ".json"
            };

            if (openDialog.ShowDialog() == true)
            {
                try
                {
                    _model = new SchellingModel(1, 1); // Temporary model
                    _model.LoadFromFile(openDialog.FileName);

                    // Update properties from loaded model
                    Width = _model.Width;
                    Height = _model.Height;
                    SimilarityThreshold = _model.SimilarityThreshold;

                    OnPropertyChanged(nameof(Width));
                    OnPropertyChanged(nameof(Height));
                    OnPropertyChanged(nameof(SimilarityThreshold));
                    OnPropertyChanged(nameof(Grid));
                    OnPropertyChanged(nameof(Cells));

                    MessageBox.Show("Model loaded successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading model: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        private void OnLeftCellClicked(object parameter)
        {
            if (parameter is Cell cell)
            {
                cell.State = cell.State switch
                {
                    CellState.Red => CellState.Empty,
                    _ => CellState.Red
                };
                OnPropertyChanged(nameof(Cells));
            }
        }

        private void OnRightCellClicked(object parameter)
        {
            if (parameter is Cell cell)
            {
                cell.State = cell.State switch
                {
                    CellState.Blue => CellState.Empty,
                    _ => CellState.Blue
                };
                OnPropertyChanged(nameof(Cells));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}